export interface IResponse {
    error:boolean;
    status:string;
    message:string;
}
